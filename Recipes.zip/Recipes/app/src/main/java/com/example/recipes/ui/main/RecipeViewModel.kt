package com.example.recipes.ui.main

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.recipes.entity.RecipeModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

class RecipeViewModel @Inject constructor(val recipeRepository: RecipeRepository) : ViewModel() {
    var allRecipes = MutableLiveData<RecipeModel>()
    var error = MutableLiveData<String>()
    fun getAllRecipes() {
        CoroutineScope(Dispatchers.IO).launch {
            val response = recipeRepository.getAllRecipes()
            withContext(Dispatchers.Main) {
                if (response.isSuccessful) {
                    allRecipes.value = response.body()
                } else {
                    error.value = response.message()
                }

            }
        }
    }
}