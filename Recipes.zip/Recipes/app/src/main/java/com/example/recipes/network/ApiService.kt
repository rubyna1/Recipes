package com.example.recipes.network

import com.example.recipes.entity.MealModel
import com.example.recipes.entity.RecipeModel
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET("/filter.php")
    fun getAllMeals(
        @Query("c") c: String
    ): Response<RecipeModel>

    @GET("/lookup.php")
    fun getMealsDetails(
        @Query("i") i: Int
    ): Response<MealModel>
}