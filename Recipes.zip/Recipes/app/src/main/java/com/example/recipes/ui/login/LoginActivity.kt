package com.example.recipes.ui.login

class LoginActivity {
}