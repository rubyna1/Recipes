package com.example.recipes.utils

object Constants {
    val BASE_URL = "https://www.themealdb.com/api/json/v1/1"
    val RECIPE_FRAGMENT="RecipeFragment"
}