package com.example.recipes.ui.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import com.example.recipes.R
import com.example.recipes.entity.Meals
import dagger.android.support.DaggerFragment
import javax.inject.Inject

class RecipeFragment : DaggerFragment() {
    @Inject
    lateinit var recipeViewModel: RecipeViewModel
    val listOfRecipes = mutableListOf<Meals>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_recipe, container, false)
    }

    override fun onViewCreated(view: View?, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialize()
    }

    private fun initialize() {
        recipeViewModel.getAllRecipes()
        recipeViewModel.allRecipes.observe(view, Observer {

        })
    }

    companion object {
        @JvmStatic
        fun newInstance() =
            RecipeFragment()
    }
}